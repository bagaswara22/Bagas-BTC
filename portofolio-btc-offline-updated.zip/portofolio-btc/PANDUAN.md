# Portofolio BTC — versi offline yang diperbarui

## Isi
- `index.html`: aplikasi.
- `manifest.json`, `sw.js`, `icons/`: dukungan PWA.
- Data transaksi disimpan di `localStorage` pada browser/perangkat ini.
- Harga BTC/IDR diisi manual; tidak ada koneksi API atau Supabase.

## Fitur
- Ringkasan saldo BTC, modal tersisa, nilai pasar, untung/rugi belum terealisasi dan terealisasi.
- Transaksi beli, jual, deposit, dan withdrawal.
- Metode harga beli rata-rata untuk menghitung basis biaya saat jual/withdrawal.
- Ringkasan bulanan.
- Ekspor JSON dan CSV serta pemulihan cadangan.
- Migrasi otomatis data pembelian dari versi sebelumnya (`portofolio-btc-v1`) saat versi baru pertama kali dibuka pada browser yang sama.

## Catatan perhitungan
- Beli: modal = jumlah BTC × harga beli + biaya transaksi.
- Jual: hasil bersih = jumlah BTC × harga jual − biaya transaksi; laba/rugi terealisasi dibanding basis biaya rata-rata.
- Deposit: pengguna memasukkan total basis biaya deposit. Jika tidak diketahui, masukkan 0; hasil untung/rugi dapat menjadi kurang akurat.
- Withdrawal: saldo dan basis biaya berkurang berdasarkan harga beli rata-rata.
- Biaya withdrawal jaringan dalam BTC belum dipisahkan sebagai kolom khusus. Masukkan jumlah BTC total yang benar-benar keluar dari saldo.

## Pasang di Android (PWA)
1. Unggah semua isi folder ini ke root repository GitHub.
2. Aktifkan GitHub Pages pada branch `main`, folder `/ (root)`.
3. Buka URL GitHub Pages melalui Chrome Android.
4. Pilih menu Chrome → Instal aplikasi / Tambahkan ke layar utama.

Alternatif: unggah folder ke Netlify Drop. PWA membutuhkan HTTPS agar service worker dan instalasi berjalan.

## Penting
- Data tidak tersinkronisasi ke perangkat lain. Ekspor JSON secara berkala.
- Jangan hapus data situs/browser sebelum membuat cadangan.
- Untuk memperbarui aplikasi, unggah file baru dan naikkan nama cache di `sw.js` (misalnya v2 menjadi v3).
- Fitur offline baru bekerja setelah aplikasi berhasil dibuka online setidaknya sekali.
